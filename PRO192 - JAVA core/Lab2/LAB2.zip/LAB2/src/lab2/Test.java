/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author hoang
 */
public class Test {

    static int choice;
    static int con = 0;
    static String input;

    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("\n----------MAIN MENU----------");
            System.out.println("1. Work with Array.");
            System.out.println("2. Work with ArrayList");
            System.out.println("-------------------------------");

            System.out.print("Enter your choice: ");
            while (!sc.hasNextInt()) {
                sc.next();
                System.out.println("Invalid choice, only numbers are allowed.");
                System.out.print("Enter your choice: ");
            }
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    arrayMenu(sc);
                    break;
                case 2:
                    arrayListMenu(sc);
                    break;
                default:
                    System.out.println("Invalid choice, please enter again!");
                    continue;
            }

            System.out.print("Do you want to continue with main menu? (y/n): ");
            input = sc.next();

            if (input.charAt(0) == 'y' || input.charAt(0) == 'Y') {
                con = 1;
            } else {
                System.out.println("\nGoodbye!");
                return;
            }
        } while (con == 1);
    }

    private static void arrayMenu(Scanner sc) {
        Person a = new Person(1, "Nguyen Van A", true);
        Person b = new Person(2, "Nguyen Van B", true);
        Person[] perArr = new Person[4];
        perArr[0] = a;
        perArr[1] = b;

        do {
            System.out.println("\n----------ARRAY MENU----------");
            System.out.println("1. Add 2 new person.");
            System.out.println("2. Display.");
            System.out.println("------------------------------");

            System.out.print("Enter your choice: ");
            while (!sc.hasNextInt()) {
                sc.next();
                System.out.println("Invalid choice, only numbers are allowed.");
                System.out.print("Enter your choice: ");
            }
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    for (int i = 2; i < perArr.length; i++) {
                        perArr[i] = new Person();
                        scanInfo(perArr[i]);
                        System.out.println("");
                    }
                    break;
                case 2:
                    for (Person ps : perArr) {
                        printInfo(ps);
                    }
                    break;
                default:
                    System.out.println("Invalid choice, please enter again!");
                    continue;
            }

            System.out.print("Do you want to exit array menu? (y/n): ");
            input = sc.next();

            if (input.charAt(0) == 'n' || input.charAt(0) == 'N') {
                con = 1;
            } else {
                System.out.println("\nGoodbye!");
                return;
            }
        } while (con == 1);
    }

    private static void arrayListMenu(Scanner sc) {
        ArrayList<Person> person_list = new ArrayList<>();
        Person e = new Person(5, "Nguyen Van E", true);
        Person f = new Person(6, "Nguyen Van F", true);
        person_list.add(e);
        person_list.add(f);
        Person g = new Person();
        Person h = new Person();

        do {
            System.out.println("\n----------ARRAY-LIST MENU----------");
            System.out.println("1. Add new person.");
            System.out.println("2. Display.");
            System.out.println("3. Sort by name.");
            System.out.println("4. Search by name.");
            System.out.println("-----------------------------------");

            System.out.print("Enter your choice: ");
            while (!sc.hasNextInt()) {
                sc.next();
                System.out.println("Invalid choice, only numbers are allowed.");
                System.out.print("Enter your choice: ");
            }
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Number of person you want to add (Added: " + person_list.size() + "): ");
                    int num = sc.nextInt();
                    for (int i = 0; i < num; i++) {
                        Person ps = new Person();
                        scanInfo(ps);
                        person_list.add(ps);
                    }
                    System.out.println("Added " + num + " person.");
                    break;
                case 2:
                    for (Person ps : person_list) {
                        printInfo(ps);
                    }
                    break;
                case 3:
                    sortByName(person_list);
                    System.out.println("Sorted!");
                    break;
                case 4:
                    System.out.print("Enter name want to search: ");
                    String search_name = sc.next();
                    int index = searchByName(person_list, search_name);
                    System.out.println("Index of person in array-list is: " + index);
                    if (index >= 0) {
                        printInfo(person_list.get(index));
                    } else {
                        System.out.println("Coudn't find out the person!");
                    }
                    break;
                default:
                    System.out.println("Invalid choice, please enter again!");
                    continue;
            }

            System.out.print("Do you want to exit array-list menu? (y/n): ");
            input = sc.next();

            if (input.charAt(0) == 'n' || input.charAt(0) == 'N') {
                con = 1;
            } else {
                System.out.println("\nGoodbye!");
                return;
            }
        } while (con == 1);
    }

    public static void scanInfo(Person p) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter ID: ");
        p.setId(input.nextInt());
        input.nextLine();
        System.out.print("Enter name: ");
        p.setName(input.nextLine());
        System.out.print("Enter gender: ");
        p.setGender(input.nextBoolean());
        System.out.println("");
    }

    public static void printInfo(Person p) {
        System.out.println("-------------------------------");
        System.out.println("| ID | Name | Male |");
        System.out.printf("| %d | %s | %s |\n", p.getId(), p.getName(), p.getGender());
    }

    private static void sortByName(ArrayList person_list) {
        for (int i = 0; i < person_list.size() - 1; i++) {
            for (int j = i + 1; j < person_list.size(); j++) {
                Person person1 = (Person) person_list.get(i);
                Person person2 = (Person) person_list.get(j);

                // Compare the names 
                int comparisonResult = person1.getName().compareTo(person2.getName());

                // Swap
                if (comparisonResult > 0) {
                    person_list.set(i, person2);
                    person_list.set(j, person1);
                }
            }
        }
    }
    
    private static int searchByName(ArrayList<Person> person_list, String search_name) {  // Specify type of ArrayList is Person to prevent error
        for (int i = 0; i < person_list.size(); i++) {
            Person per = person_list.get(i);

            if (per.getName().compareTo(search_name) == 0) {
                return i;
            }
        }
        return -1;
    }
}
